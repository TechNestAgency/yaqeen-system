@extends('layouts.index')

@section('content')
    <!-- Page main content START -->
    <div class="page-content-wrapper border">

        <!-- Title -->
        <div class="row">
            <div class="col-8">
                <h1 class="h3 mb-2 mb-sm-0">اضافة طالب</h1>
            </div>
        </div><br>

    </div>
    <!-- Page main content END -->
@endsection
